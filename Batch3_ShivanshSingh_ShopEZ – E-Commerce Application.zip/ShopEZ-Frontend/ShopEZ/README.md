# 🛒 ShopEZ – E-Commerce Frontend Application

## 📌 Project Overview
ShopEZ is a frontend-only e-commerce web application built to demonstrate modern web development concepts. 
It allows users to browse products, view details, manage a shopping cart, and simulate checkout — all without a backend.

---

## 🚀 Technologies Used
- HTML5  
- CSS3  
- JavaScript (ES6)  
- Bootstrap 5  
- jQuery  
- LocalStorage  
- JSON  

---

## 🎯 Features
- Product listing page  
- Product details page  
- Add to cart functionality  
- Remove from cart  
- Cart total calculation  
- Checkout simulation  
- Responsive design  

---

## 🗂️ Project Structure

ShopEZ-Frontend
│
├── index.html
├── products.html
├── product-details.html
├── cart.html
├── checkout.html
│
├── css/
│   └── styles.css
│
├── js/
│   ├── products.js
│   ├── cart.js
│   ├── checkout.js
│   └── common.js
│
├── data/
│   └── products.json
│
├── images/
│
└── lib/
    ├── bootstrap/
    └── jquery/

---

## 🧾 Product Data Example

```json
[
  {
    "id": 1,
    "name": "Laptop",
    "description": "High performance laptop",
    "price": 60000,
    "image": "images/laptop.jpg"
  }
]
```

---

## 🔄 Application Flow
Home → Products → Product Details → Cart → Checkout

---

## 🧪 Testing
- Products load correctly  
- Cart updates properly  
- Total price calculates accurately  
- Checkout form validates inputs  

---

## 🔮 Future Enhancements
- Backend integration  
- User authentication  
- Payment gateway  

---

## 🏁 Conclusion
ShopEZ demonstrates a complete frontend e-commerce workflow using modern web technologies.
