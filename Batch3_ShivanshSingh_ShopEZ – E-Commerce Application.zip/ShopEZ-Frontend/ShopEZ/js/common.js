 

$(document).ready(function () {
  updateCartBadge();
  setActiveNav();
});

 
function updateCartBadge() {
  const cart = getCart();
  const $badge = $('.cart-badge');
  if (cart.length > 0) {
    $badge.text(cart.length).show();
  } else {
    $badge.hide();
  }
}

 
function getCart() {
  return JSON.parse(localStorage.getItem('shopez_cart')) || [];
}

function saveCart(cart) {
  localStorage.setItem('shopez_cart', JSON.stringify(cart));
  updateCartBadge();
}

function clearCart() {
  localStorage.removeItem('shopez_cart');
  updateCartBadge();
}
 
function setActiveNav() {
  const page = location.pathname.split('/').pop() || 'index.html';
  $('.nav-link-custom').each(function () {
    const href = $(this).attr('href');
    if (href === page || (page === '' && href === 'index.html')) {
      $(this).addClass('active');
    }
  });
}

 
function showToast(message, icon = '✓') {
  const $container = $('.toast-container-shopez');
  const $toast = $(`
    <div class="toast-shopez">
      <span class="toast-icon">${icon}</span>
      <span>${message}</span>
    </div>
  `);
  $container.append($toast);
  setTimeout(() => {
    $toast.addClass('removing');
    setTimeout(() => $toast.remove(), 300);
  }, 2800);
}

 
function formatPrice(price) {
  return '₹' + price.toLocaleString('en-IN');
}

 
function renderStars(rating) {
  let stars = '';
  const full = Math.floor(rating);
  const half = rating % 1 >= 0.5;
  for (let i = 0; i < full; i++) stars += '★';
  if (half) stars += '½';
  while (stars.replace('½','').length < 5) stars += '☆';
  return stars;
}
