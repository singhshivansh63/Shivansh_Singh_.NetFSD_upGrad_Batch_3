 

let allProducts = [];

$(document).ready(function () {
  loadProducts();
});

 
  window.addEventListener('offline', () => {
    console.log("You are offline");
    renderProducts(allProducts);
  });

  window.addEventListener('online', () => {
    console.log("You are back online");
    renderProducts(allProducts);
  });


function loadProducts() {
  showSkeletons();
  $.getJSON('data/products.json', function (products) {
    allProducts = products;
    renderProducts(products);
    setupCategoryFilter(products);
  }).fail(function () {
    $('#products-grid').html(`
      <div class="col-12 text-center py-5">
        <p style="color:var(--text-muted)">Could not load products. Make sure products.json exists.</p>
      </div>
    `);
  });
}

function showSkeletons() {
  let html = '';
  for (let i = 0; i < 6; i++) {
    html += `
      <div class="col-lg-4 col-md-6 mb-4">
        <div class="product-card" style="pointer-events:none">
          <div class="product-img-wrap skeleton" style="aspect-ratio:4/3"></div>
          <div class="product-card-body">
            <div class="skeleton mb-2" style="height:12px;width:60%"></div>
            <div class="skeleton mb-2" style="height:18px;width:80%"></div>
            <div class="skeleton mb-3" style="height:12px;width:100%"></div>
            <div style="display:flex;justify-content:space-between;align-items:center">
              <div class="skeleton" style="height:22px;width:30%"></div>
              <div class="skeleton" style="height:34px;width:38%"></div>
            </div>
          </div>
        </div>
      </div>`;
  }
  $('#products-grid').html(html);
}

function renderProducts(products) {
  if (products.length === 0) {
    $('#products-grid').html(`
      <div class="col-12 text-center py-5">
        <p style="color:var(--text-muted);font-size:1.1rem">No products found in this category.</p>
      </div>`);
    return;
  }

  let html = '';
  products.forEach((p, i) => {
    html += `
      <div class="col-lg-4 col-md-6 mb-4 fade-in" style="animation-delay:${i * 0.06}s">
        <div class="product-card" data-id="${p.id}">
          <div class="product-img-wrap">
            <img 
  <img 
  src="${p.image}" 
  alt="${p.name}" 
  loading="lazy"
  onerror="this.onerror=null; this.src='${p.localImage}'">
   
            <span class="product-badge">${p.category}</span>
          </div>
          <div class="product-card-body">
            <div class="product-category">${p.category}</div>
            <div class="product-name">${p.name}</div>
            <div class="product-desc">${p.description}</div>
            <div class="product-rating">
              <span class="stars">${renderStars(p.rating)}</span>
              <span class="rating-num">${p.rating} / 5</span>
            </div>
            <div class="product-footer">
              <div class="product-price">
                <span class="currency">₹</span>${p.price.toLocaleString('en-IN')}
              </div>
              <div style="display:flex;gap:8px">
                <button class="btn-view-details" onclick="viewProduct(${p.id})">Details</button>
                <button class="btn-add-cart" id="cart-btn-${p.id}" onclick="addToCartFromList(${p.id})">+ Cart</button>
              </div>
            </div>
          </div>
        </div>
      </div>`;
  });

  $('#products-grid').html(html);
  refreshCartButtonStates();
}

function setupCategoryFilter(products) {
  const categories = ['All', ...new Set(products.map(p => p.category))];
  let pillsHtml = '';
  categories.forEach((cat, i) => {
    pillsHtml += `<span class="cat-pill ${i === 0 ? 'active' : ''}" data-cat="${cat}">${cat}</span>`;
  });
  $('#category-pills').html(pillsHtml);

  $(document).on('click', '.cat-pill', function () {
    $('.cat-pill').removeClass('active');
    $(this).addClass('active');
    const cat = $(this).data('cat');
    const filtered = cat === 'All' ? allProducts : allProducts.filter(p => p.category === cat);
    renderProducts(filtered);
  });
}

function viewProduct(id) {
  window.location.href = `product-details.html?id=${id}`;
}

function addToCartFromList(id) {
  const product = allProducts.find(p => p.id === id);
  if (!product) return;

  let cart = getCart();
  const exists = cart.find(i => i.id === id);
  if (exists) {
    showToast(`${product.name} is already in your cart`, '🛒');
    return;
  }

  addToCart(product);
  showToast(`${product.name} added to cart!`, '✓');

  const $btn = $(`#cart-btn-${id}`);
  $btn.text('✓ Added').addClass('added');
  setTimeout(() => $btn.text('+ Cart').removeClass('added'), 2000);
}

function refreshCartButtonStates() {
  const cart = getCart();
  const cartIds = cart.map(i => i.id);
  cartIds.forEach(id => {
    const $btn = $(`#cart-btn-${id}`);
    if ($btn.length) {
      $btn.text('✓ Added').addClass('added');
    }
  });
}
