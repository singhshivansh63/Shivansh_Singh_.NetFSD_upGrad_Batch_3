 

$(document).ready(function () {
  if ($('#checkout-order-summary').length) {
    renderOrderSummary();
    setupCheckoutForm();
  }
});

function renderOrderSummary() {
  const cart = getCart();

  if (cart.length === 0) {
    window.location.href = 'cart.html';
    return;
  }

  let html = '';
  cart.forEach(item => {
    html += `
      <div class="order-item-mini">
        <img src="${item.image}" alt="${item.name}"
             onerror="this.src='https://via.placeholder.com/48x38/16161a/f0c040?text=IMG'">
        <div class="order-item-mini-name">${item.name}</div>
        <div class="order-item-mini-price">${formatPrice(item.price)}</div>
      </div>`;
  });

  $('#checkout-order-summary').html(html);

  const subtotal = calculateTotal(cart);
  const shipping = 99;
  const total = subtotal + shipping;

  $('#checkout-subtotal').text(formatPrice(subtotal));
  $('#checkout-shipping').text(formatPrice(shipping));
  $('#checkout-total').text(formatPrice(total));
}

function setupCheckoutForm() {
  $('#checkout-form').on('submit', function (e) {
    e.preventDefault();

    const name     = $('#input-name').val().trim();
    const email    = $('#input-email').val().trim();
    const phone    = $('#input-phone').val().trim();
    const address  = $('#input-address').val().trim();
    const city     = $('#input-city').val().trim();
    const pincode  = $('#input-pincode').val().trim();

  
    if (!name || !email || !phone || !address || !city || !pincode) {
      showToast('Please fill in all required fields', '⚠️');
      return;
    }
 
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      showToast('Please enter a valid email address', '⚠️');
      return;
    }
 
    const digitsOnly = phone.replace(/[\s\-().+]/g, '');
    if (!/^[6-9]\d{9}$/.test(digitsOnly)) {
      showToast('Please enter a valid 10-digit mobile number', '⚠️');
      return;
    }

   
    if (!/^\d{6}$/.test(pincode)) {
      showToast('Please enter a valid 6-digit PIN code', '⚠️');
      return;
    }

    
    const $btn = $('#btn-place-order');
    $btn.text('Processing...').prop('disabled', true).css('opacity', 0.7);

    setTimeout(() => {
      clearCart();
      showSuccessModal(name);
    }, 1400);
  });
}

function showSuccessModal(name) {
  const orderId = 'SEZ' + Math.floor(100000 + Math.random() * 900000);
  $('#order-id-display').text(orderId);
  $('#success-name').text(name.split(' ')[0]);
  $('#success-overlay').addClass('show');
}

$('#btn-continue-shopping').on('click', function () {
  window.location.href = 'index.html';
});
