 

function addToCart(product) {
  let cart = getCart();
  const exists = cart.find(i => i.id === product.id);
  if (!exists) {
    cart.push({
      id: product.id,
      name: product.name,
      price: product.price,
      image: product.image,
      category: product.category
    });
    saveCart(cart);
  }
}

function removeFromCart(id) {
  let cart = getCart();
  cart = cart.filter(i => i.id !== id);
  saveCart(cart);
}

function calculateTotal(cart) {
  return cart.reduce((sum, item) => sum + item.price, 0);
}

 
$(document).ready(function () {
  if ($('#cart-items-container').length) {
    renderCartPage();
  }
});

function renderCartPage() {
  const cart = getCart();
  const $container = $('#cart-items-container');
  const $empty = $('#cart-empty');
  const $cartContent = $('#cart-content');

  if (cart.length === 0) {
    $empty.show();
    $cartContent.hide();
    return;
  }

  $empty.hide();
  $cartContent.show();

  let html = '';
  cart.forEach(item => {
    html += `
      <div class="cart-item" id="cart-item-${item.id}">
        <img class="cart-item-img"
             src="${item.image}"
             alt="${item.name}"
             onerror="this.src='https://via.placeholder.com/90x70/16161a/f0c040?text=IMG'">
        <div class="cart-item-info">
          <div class="cart-item-name">${item.name}</div>
          <div class="cart-item-category">${item.category}</div>
        </div>
        <div class="cart-item-price">${formatPrice(item.price)}</div>
        <button class="btn-remove-cart" onclick="handleRemove(${item.id})" title="Remove item">✕</button>
      </div>`;
  });

  $container.html(html);
  updateSummary(cart);
}

function handleRemove(id) {
  const cart = getCart();
  const item = cart.find(i => i.id === id);
  if (!item) return;

  const $item = $(`#cart-item-${id}`);
  $item.css({ transition: 'all 0.3s ease', opacity: 0, transform: 'translateX(30px)' });

  setTimeout(() => {
    removeFromCart(id);
    showToast(`${item.name} removed`, '🗑️');
    renderCartPage();
  }, 280);
}

function updateSummary(cart) {
  const subtotal = calculateTotal(cart);
  const shipping = cart.length > 0 ? 99 : 0;
  const total = subtotal + shipping;

  $('#summary-subtotal').text(formatPrice(subtotal));
  $('#summary-shipping').text(cart.length > 0 ? formatPrice(shipping) : 'Free');
  $('#summary-total').text(formatPrice(total));
  $('#summary-count').text(`${cart.length} item${cart.length !== 1 ? 's' : ''}`);
}
