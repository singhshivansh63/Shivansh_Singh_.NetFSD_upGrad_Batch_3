using Microsoft.EntityFrameworkCore;
using ShopEZ_Backend_API.Data;
using ShopEZ_Backend_API.Models;
using ShopEZ_Backend_API.Repositories.Interfaces;

namespace ShopEZ_Backend_API.Repositories
{
    public class OrderRepository : IOrderRepository
    {
        private readonly ApplicationDbContext _context;

        public OrderRepository(ApplicationDbContext context)
        {
            _context = context;
        }

        /// <summary>Returns all orders with their related User and OrderItems (including Product info).</summary>
        public async Task<IEnumerable<Order>> GetAllAsync()
        {
            return await _context.Orders
                                 .AsNoTracking()
                                 .Include(o => o.User)
                                 .Include(o => o.OrderItems)
                                     .ThenInclude(oi => oi.Product)
                                 .OrderByDescending(o => o.OrderDate)
                                 .ToListAsync();
        }

        /// <summary>Returns a single order by ID with all related data, or null if not found.</summary>
        public async Task<Order?> GetByIdAsync(int id)
        {
            return await _context.Orders
                                 .AsNoTracking()
                                 .Include(o => o.User)
                                 .Include(o => o.OrderItems)
                                     .ThenInclude(oi => oi.Product)
                                 .FirstOrDefaultAsync(o => o.OrderId == id);
        }

        /// <summary>Persists a new order (with its OrderItems) and returns the saved entity.</summary>
        public async Task<Order> AddAsync(Order order)
        {
            await _context.Orders.AddAsync(order);
            return order; // ✅ Only add, don't save
        }
    }
}
