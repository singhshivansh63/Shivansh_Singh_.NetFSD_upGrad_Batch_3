using Microsoft.AspNetCore.Mvc;
using ShopEZ_Backend_API.DTOs;
using ShopEZ_Backend_API.Services.Interfaces;

namespace ShopEZ_Backend_API.Controllers
{
    /// <summary>
    /// Handles order creation and retrieval.
    /// </summary>
    [ApiController]
    [Route("api/orders")]
    [Produces("application/json")]
    public class OrdersController : ControllerBase
    {
        private readonly IOrderService _orderService;
        private readonly ILogger<OrdersController> _logger;

        public OrdersController(IOrderService orderService, ILogger<OrdersController> logger)
        {
            _orderService = orderService;
            _logger       = logger;
        }

        // ──────────────────────────────────────────────────────────────────────
        // POST /api/orders
        // ──────────────────────────────────────────────────────────────────────
        /// <summary>
        /// Creates a new order from the frontend cart items.
        /// Validates products, checks stock, calculates total, and persists the order.
        /// </summary>
        /// <param name="dto">Order creation payload containing UserId and CartItems.</param>
        /// <response code="201">Order created successfully. Returns the full order detail.</response>
        /// <response code="400">Invalid input, quantity ≤ 0, or insufficient stock.</response>
        /// <response code="404">User or product not found.</response>
        [HttpPost]
        [ProducesResponseType(typeof(OrderDTO), StatusCodes.Status201Created)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        public async Task<IActionResult> CreateOrder([FromBody] CreateOrderDTO dto)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            _logger.LogInformation("POST /api/orders called for UserId {UserId}.", dto.UserId);
            var created = await _orderService.CreateOrderAsync(dto);
            return CreatedAtAction(nameof(GetOrder), new { id = created.OrderId }, created);
        }

        // ──────────────────────────────────────────────────────────────────────
        // GET /api/orders
        // ──────────────────────────────────────────────────────────────────────
        /// <summary>Retrieves a summary list of all orders.</summary>
        /// <response code="200">Returns all orders with summary info.</response>
        [HttpGet]
        [ProducesResponseType(typeof(IEnumerable<OrderSummaryDTO>), StatusCodes.Status200OK)]
        public async Task<IActionResult> GetAllOrders()
        {
            _logger.LogInformation("GET /api/orders called.");
            var orders = await _orderService.GetAllOrdersAsync();
            return Ok(orders);
        }

        // ──────────────────────────────────────────────────────────────────────
        // GET /api/orders/{id}
        // ──────────────────────────────────────────────────────────────────────
        /// <summary>Retrieves a specific order by ID with full item details.</summary>
        /// <param name="id">Order ID</param>
        /// <response code="200">Returns the full order including line items.</response>
        /// <response code="404">Order not found.</response>
        [HttpGet("{id:int}")]
        [ProducesResponseType(typeof(OrderDTO), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        public async Task<IActionResult> GetOrder(int id)
        {
            _logger.LogInformation("GET /api/orders/{Id} called.", id);
            var order = await _orderService.GetOrderByIdAsync(id);
            return Ok(order);
        }
    }
}
