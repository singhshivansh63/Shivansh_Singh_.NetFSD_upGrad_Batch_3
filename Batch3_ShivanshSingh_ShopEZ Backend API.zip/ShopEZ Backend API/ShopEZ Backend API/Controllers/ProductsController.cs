using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using ShopEZ_Backend_API.DTOs;
using ShopEZ_Backend_API.Services.Interfaces;

namespace ShopEZ_Backend_API.Controllers
{
    [ApiController]
    [Route("api/products")]
    [Produces("application/json")]
    public class ProductsController : ControllerBase
    {
        private readonly IProductService _productService;
        private readonly ILogger<ProductsController> _logger;

        public ProductsController(IProductService productService, ILogger<ProductsController> logger)
        {
            _productService = productService;
            _logger = logger;
        }

        

        // ─────────────────────────────────────────────────────────────
        // GET ALL PRODUCTS (WITH PAGINATION)
        // ─────────────────────────────────────────────────────────────
        [HttpGet]
        [ProducesResponseType(typeof(IEnumerable<ProductDTO>), StatusCodes.Status200OK)]
        public async Task<IActionResult> GetProducts(int page = 1, int pageSize = 5)
        {
            _logger.LogInformation("GET /api/products called. Page={Page}, PageSize={PageSize}", page, pageSize);

            var products = await _productService.GetAllProductsAsync(page, pageSize);
            return Ok(products);
        }

        // ─────────────────────────────────────────────────────────────
        // GET BY ID
        // ─────────────────────────────────────────────────────────────
        [HttpGet("{id:int}")]
        [ProducesResponseType(typeof(ProductDTO), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        public async Task<IActionResult> GetProduct(int id)
        {
            _logger.LogInformation("GET product {Id}", id);

            var product = await _productService.GetProductByIdAsync(id);
            return Ok(product);
        }

        // ─────────────────────────────────────────────────────────────
        // CREATE PRODUCT (ADMIN ONLY)
        // ─────────────────────────────────────────────────────────────
        [Authorize(Roles = "Admin")]
        [HttpPost]
        [ProducesResponseType(typeof(ProductDTO), StatusCodes.Status201Created)]
        public async Task<IActionResult> CreateProduct([FromBody] CreateProductDTO dto)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            _logger.LogInformation("Creating product");

            var created = await _productService.CreateProductAsync(dto);

            return CreatedAtAction(nameof(GetProduct),
                new { id = created.ProductId },
                created);
        }

        // ─────────────────────────────────────────────────────────────
        // UPDATE PRODUCT (ADMIN ONLY)
        // ─────────────────────────────────────────────────────────────
        [Authorize(Roles = "Admin")]
        [HttpPut("{id:int}")]
        [ProducesResponseType(typeof(ProductDTO), StatusCodes.Status200OK)]
        public async Task<IActionResult> UpdateProduct(int id, [FromBody] UpdateProductDTO dto)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            _logger.LogInformation("Updating product {Id}", id);

            var updated = await _productService.UpdateProductAsync(id, dto);
            return Ok(updated);
        }

        // ─────────────────────────────────────────────────────────────
        // DELETE PRODUCT (ADMIN ONLY)
        // ─────────────────────────────────────────────────────────────
        [Authorize(Roles = "Admin")]
        [HttpDelete("{id:int}")]
        [ProducesResponseType(StatusCodes.Status204NoContent)]
        public async Task<IActionResult> DeleteProduct(int id)
        {
            _logger.LogInformation("Deleting product {Id}", id);

            await _productService.DeleteProductAsync(id);
            return NoContent();
        }
    }
}
