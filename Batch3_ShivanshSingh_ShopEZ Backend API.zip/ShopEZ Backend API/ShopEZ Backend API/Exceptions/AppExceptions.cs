namespace ShopEZ_Backend_API.Exceptions
{
    /// <summary>Thrown when a requested resource cannot be found in the database.</summary>
    public class NotFoundException : Exception
    {
        public NotFoundException(string message) : base(message) { }
    }

    /// <summary>Thrown when input data fails business-logic validation.</summary>
    public class ValidationException : Exception
    {
        public ValidationException(string message) : base(message) { }
    }
}
