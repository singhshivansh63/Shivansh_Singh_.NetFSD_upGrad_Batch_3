using System.ComponentModel.DataAnnotations;

namespace ShopEZ_Backend_API.Models
{
    public class User
    {
        [Key]
        public int UserId { get; set; }

        [Required]
        [MaxLength(100)]
        public string Name { get; set; } = string.Empty;

        [Required]
        [MaxLength(150)]
        [EmailAddress]
        public string Email { get; set; } = string.Empty;

        [Required]
        [MaxLength(256)]
        public string Password { get; set; } = string.Empty;

        [MaxLength(50)]
        public string Role { get; set; } = "Customer";

        // Navigation property
        public ICollection<Order> Orders { get; set; } = new List<Order>();
    }
}
