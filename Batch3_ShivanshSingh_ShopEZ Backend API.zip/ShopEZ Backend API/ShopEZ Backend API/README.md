# ShopEZ – Backend API (Phase 2)

> ASP.NET Core 8 Web API · Entity Framework Core 8 · SQL Server · Swagger

---

## Table of Contents

1. [Project Overview](#project-overview)  
2. [Architecture](#architecture)  
3. [Folder Structure](#folder-structure)  
4. [Database Design](#database-design)  
5. [Prerequisites](#prerequisites)  
6. [Setup & Run](#setup--run)  
7. [API Endpoints](#api-endpoints)  
8. [Order Processing Logic](#order-processing-logic)  
9. [Validation & Error Handling](#validation--error-handling)  
10. [Swagger Documentation](#swagger-documentation)  
11. [Postman Testing](#postman-testing)  
12. [Seed Data](#seed-data)  

---

## Project Overview

ShopEZ Phase 2 replaces the Phase-1 static JSON/LocalStorage prototype with a full backend powered by:

| Layer | Technology |
|---|---|
| API | ASP.NET Core 8 Web API |
| ORM | Entity Framework Core 8 |
| Database | SQL Server (LocalDB / full) |
| Docs | Swagger (Swashbuckle) |
| Testing | Postman |

---

## Architecture

```
HTTP Request
    │
    ▼
┌─────────────────────┐
│   Controller Layer  │  ← Handles HTTP, model validation, status codes
│  (ProductsController│
│   OrdersController) │
└────────┬────────────┘
         │ calls
         ▼
┌─────────────────────┐
│   Service Layer     │  ← Business logic, LINQ, validation, mapping
│  (ProductService    │
│   OrderService)     │
└────────┬────────────┘
         │ calls
         ▼
┌─────────────────────┐
│  Repository Layer   │  ← EF Core data access, CRUD, eager loading
│  (ProductRepository │
│   OrderRepository)  │
└────────┬────────────┘
         │ uses
         ▼
┌─────────────────────┐
│  ApplicationDbContext│  ← EF Core DbContext, migrations, seed data
└─────────────────────┘
         │
         ▼
   SQL Server Database
```

---

## Folder Structure

```
ShopEZ.API/
│
├── Controllers/
│   ├── ProductsController.cs     ← CRUD endpoints for products
│   └── OrdersController.cs       ← Create & retrieve orders
│
├── Models/                        ← EF Core entity classes
│   ├── User.cs
│   ├── Product.cs
│   ├── Order.cs
│   └── OrderItem.cs
│
├── DTOs/                          ← Data Transfer Objects (no entity exposure)
│   ├── ProductDTO.cs              ← ProductDTO, CreateProductDTO, UpdateProductDTO
│   └── OrderDTO.cs                ← OrderDTO, CreateOrderDTO, CartItemDTO, etc.
│
├── Data/
│   └── ApplicationDbContext.cs    ← DbContext, fluent config, seed data
│
├── Repositories/
│   ├── Interfaces/
│   │   ├── IProductRepository.cs
│   │   └── IOrderRepository.cs
│   ├── ProductRepository.cs
│   └── OrderRepository.cs
│
├── Services/
│   ├── Interfaces/
│   │   ├── IProductService.cs
│   │   └── IOrderService.cs
│   ├── ProductService.cs
│   └── OrderService.cs
│
├── Middleware/
│   └── GlobalExceptionMiddleware.cs   ← Centralized error handling
│
├── Exceptions/
│   └── AppExceptions.cs               ← NotFoundException, ValidationException
│
├── Migrations/                        ← EF Core migration files
│
├── appsettings.json
├── appsettings.Development.json
├── Program.cs                         ← DI registration, middleware pipeline
├── ShopEZ.API.csproj
└── ShopEZ_Postman_Collection.json     ← Import this into Postman
```

---

## Database Design

### Tables & Relationships

```
Users (1) ───────────< Orders (many)
                            │
                            └─────────< OrderItems (many)
                                              │
Products (1) ──────────────────────────────<─┘
```

| Table | Primary Key | Foreign Keys |
|---|---|---|
| Users | UserId | — |
| Products | ProductId | — |
| Orders | OrderId | UserId → Users |
| OrderItems | OrderItemId | OrderId → Orders, ProductId → Products |

**Delete behaviours:**  
- User deleted → Orders restricted (cannot delete user with orders)  
- Order deleted → OrderItems cascade-deleted  
- Product deleted → OrderItems restricted  

---

## Prerequisites

| Tool | Minimum Version |
|---|---|
| .NET SDK | 8.0 |
| SQL Server | 2019 / LocalDB / Express |
| Visual Studio | 2022 (or VS Code + C# extension) |
| Postman | Any recent version |

---

## Setup & Run

### Step 1 – Clone / Extract the project

```bash
# Extract the zip and open the folder
cd ShopEZ.API
```

### Step 2 – Configure the connection string

Open `appsettings.json` and update `DefaultConnection` to match your SQL Server:

```json
"ConnectionStrings": {
  "DefaultConnection": "Server=localhost;Database=ShopEZDB;Trusted_Connection=True;TrustServerCertificate=True;"
}
```

**For SQL Server Authentication (username/password):**

```json
"DefaultConnection": "Server=localhost;Database=ShopEZDB;User Id=sa;Password=YourPassword;TrustServerCertificate=True;"
```

**For LocalDB:**

```json
"DefaultConnection": "Server=(localdb)\\mssqllocaldb;Database=ShopEZDB;Trusted_Connection=True;"
```

### Step 3 – Restore NuGet packages

```bash
dotnet restore
```

### Step 4 – Apply migrations & seed database

> The application **auto-applies migrations on startup** via `db.Database.Migrate()` in `Program.cs`.  
> Alternatively, run manually:

```bash
dotnet ef database update
```

This will:
- Create the `ShopEZDB` database
- Create all 4 tables with relationships
- Seed 3 users and 5 products

### Step 5 – Run the application

```bash
dotnet run
```

Or press **F5** in Visual Studio.

The API will start at:
- **HTTP:**  `http://localhost:5000`
- **HTTPS:** `https://localhost:7001`
- **Swagger UI:** `https://localhost:7001` (root URL)

---

## API Endpoints

### Products

| Method | Endpoint | Description | Success Code |
|---|---|---|---|
| GET | `/api/products` | Get all products | 200 OK |
| GET | `/api/products/{id}` | Get product by ID | 200 OK |
| POST | `/api/products` | Create new product | 201 Created |
| PUT | `/api/products/{id}` | Update product | 200 OK |
| DELETE | `/api/products/{id}` | Delete product | 204 No Content |

#### POST /api/products – Request Body

```json
{
  "name": "Gaming Headset",
  "description": "7.1 surround sound headset.",
  "price": 4599.99,
  "imageUrl": "https://example.com/image.jpg",
  "stock": 40
}
```

#### POST /api/products – Response (201)

```json
{
  "productId": 6,
  "name": "Gaming Headset",
  "description": "7.1 surround sound headset.",
  "price": 4599.99,
  "imageUrl": "https://example.com/image.jpg",
  "stock": 40
}
```

---

### Orders

| Method | Endpoint | Description | Success Code |
|---|---|---|---|
| POST | `/api/orders` | Create order from cart | 201 Created |
| GET | `/api/orders` | Get all orders (summary) | 200 OK |
| GET | `/api/orders/{id}` | Get order by ID (detail) | 200 OK |

#### POST /api/orders – Request Body

```json
{
  "userId": 2,
  "cartItems": [
    { "productId": 1, "quantity": 2 },
    { "productId": 3, "quantity": 1 }
  ]
}
```

#### POST /api/orders – Response (201)

```json
{
  "orderId": 1,
  "userId": 2,
  "userName": "John Doe",
  "orderDate": "2024-01-15T10:30:00Z",
  "totalAmount": 8799.48,
  "orderItems": [
    {
      "orderItemId": 1,
      "productId": 1,
      "productName": "Wireless Headphones",
      "quantity": 2,
      "price": 2999.99,
      "subTotal": 5999.98
    },
    {
      "orderItemId": 2,
      "productId": 3,
      "productName": "USB-C Hub 7-in-1",
      "quantity": 1,
      "price": 1799.50,
      "subTotal": 1799.50
    }
  ]
}
```

---

## Order Processing Logic

When `POST /api/orders` is called, the `OrderService` executes this pipeline:

```
1. Validate DTO is not null
2. Validate cart is not empty
3. Verify user exists in database          → 404 if not found
4. For each cart item:
   a. Validate quantity > 0               → 400 if invalid
   b. Fetch product from database         → 404 if not found
   c. Check product.Stock >= quantity     → 400 if insufficient
   d. Snapshot product.Price into OrderItem
5. Calculate TotalAmount = SUM(price * quantity)  ← LINQ
6. Build Order entity with OrderItems
7. Save Order + OrderItems to database (single transaction)
8. Decrement stock for each purchased product
9. Reload order with navigation properties
10. Return mapped OrderDTO
```

---

## Validation & Error Handling

### Input Validation

- All DTOs use `[Required]`, `[Range]`, `[MaxLength]` data annotations
- ModelState validation in controllers (400 for model errors)
- Business rule validation in services (via custom exceptions)

### HTTP Status Codes

| Scenario | Code |
|---|---|
| Success – data returned | 200 OK |
| Resource created | 201 Created |
| Success – no body | 204 No Content |
| Validation / bad input | 400 Bad Request |
| Resource not found | 404 Not Found |
| Server error | 500 Internal Server Error |

### Error Response Format

```json
{
  "status": 404,
  "error": "NotFound",
  "message": "Product with ID 99 was not found."
}
```

### GlobalExceptionMiddleware

All exceptions bubble up to `GlobalExceptionMiddleware`, which maps:
- `NotFoundException` → **404**
- `ValidationException` → **400**
- Everything else → **500**

---

## Swagger Documentation

Swagger UI is available at the **root URL** when running in Development mode:

```
https://localhost:7001
```

All endpoints, request bodies, and response schemas are documented. You can test endpoints directly from the Swagger UI.

---

## Postman Testing

1. Open Postman
2. Click **Import**
3. Select `ShopEZ_Postman_Collection.json` (in the project root)
4. The collection contains **15 pre-built requests** covering:
   - All CRUD operations for products
   - Happy-path and error-path order scenarios
   - Validation tests (400 / 404 cases)
5. Set the `baseUrl` variable to match your running port if needed (default: `https://localhost:7001`)

---

## Seed Data

The following data is seeded automatically on first run:

### Users

| UserId | Name | Email | Role |
|---|---|---|---|
| 1 | Admin User | admin@shopez.com | Admin |
| 2 | John Doe | john@example.com | Customer |
| 3 | Jane Smith | jane@example.com | Customer |

### Products

| ProductId | Name | Price | Stock |
|---|---|---|---|
| 1 | Wireless Headphones | ₹2,999.99 | 50 |
| 2 | Mechanical Keyboard | ₹3,499.00 | 30 |
| 3 | USB-C Hub 7-in-1 | ₹1,799.50 | 100 |
| 4 | Ergonomic Mouse | ₹1,299.00 | 75 |
| 5 | 27-inch Monitor | ₹24,999.00 | 20 |

---

## Regenerating Migrations (if needed)

If you modify models and need fresh migrations:

```bash
# Delete the existing Migrations folder, then:
dotnet ef migrations add InitialCreate
dotnet ef database update
```
