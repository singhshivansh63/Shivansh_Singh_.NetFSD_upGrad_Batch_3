using ShopEZ_Backend_API.DTOs;

namespace ShopEZ_Backend_API.Services.Interfaces
{
    public interface IProductService
    {
        // ✅ GET ALL WITH PAGINATION
        Task<IEnumerable<ProductDTO>> GetAllProductsAsync(int page = 1, int pageSize = 5);

        // ✅ GET BY ID
        Task<ProductDTO> GetProductByIdAsync(int id);

        // ✅ CREATE
        Task<ProductDTO> CreateProductAsync(CreateProductDTO dto);

        // ✅ UPDATE
        Task<ProductDTO> UpdateProductAsync(int id, UpdateProductDTO dto);

        // ✅ DELETE
        Task DeleteProductAsync(int id);
    }
}