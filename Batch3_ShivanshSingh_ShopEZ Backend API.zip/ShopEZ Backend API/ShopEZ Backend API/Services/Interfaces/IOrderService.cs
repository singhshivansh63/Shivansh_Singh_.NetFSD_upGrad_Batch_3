using ShopEZ_Backend_API.DTOs;

namespace ShopEZ_Backend_API.Services.Interfaces
{
    public interface IOrderService
    {
        Task<OrderDTO> CreateOrderAsync(CreateOrderDTO dto);
        Task<IEnumerable<OrderSummaryDTO>> GetAllOrdersAsync();
        Task<OrderDTO> GetOrderByIdAsync(int id);
    }
}
