using ShopEZ_Backend_API.DTOs;
using ShopEZ_Backend_API.Exceptions;
using ShopEZ_Backend_API.Models;
using ShopEZ_Backend_API.Repositories.Interfaces;
using ShopEZ_Backend_API.Services.Interfaces;

namespace ShopEZ_Backend_API.Services
{
    public class ProductService : IProductService
    {
        private readonly IProductRepository _productRepository;
        private readonly ILogger<ProductService> _logger;

        public ProductService(IProductRepository productRepository, ILogger<ProductService> logger)
        {
            _productRepository = productRepository;
            _logger = logger;
        }

        // ──────────────────────────────────────────────────────────────────────
        // GET ALL (WITH PAGINATION)
        // ──────────────────────────────────────────────────────────────────────
        public async Task<IEnumerable<ProductDTO>> GetAllProductsAsync(int page = 1, int pageSize = 5)
        {
            if (page <= 0 || pageSize <= 0)
                throw new ValidationException("Page and PageSize must be greater than zero.");

            _logger.LogInformation("Fetching products. Page: {Page}, PageSize: {PageSize}", page, pageSize);

            var products = await _productRepository.GetAllAsync();

            var paged = products
                .Skip((page - 1) * pageSize)
                .Take(pageSize);

            return paged.Select(MapToDTO);
        }

        // ──────────────────────────────────────────────────────────────────────
        // GET BY ID
        // ──────────────────────────────────────────────────────────────────────
        public async Task<ProductDTO> GetProductByIdAsync(int id)
        {
            if (id <= 0)
                throw new ValidationException("Invalid Product ID.");

            _logger.LogInformation("Fetching product with ID {Id}.", id);

            var product = await _productRepository.GetByIdAsync(id)
                          ?? throw new NotFoundException($"Product with ID {id} was not found.");

            return MapToDTO(product);
        }

        // ──────────────────────────────────────────────────────────────────────
        // CREATE
        // ──────────────────────────────────────────────────────────────────────
        public async Task<ProductDTO> CreateProductAsync(CreateProductDTO dto)
        {
            if (dto is null)
                throw new ValidationException("Product data cannot be null.");

            if (string.IsNullOrWhiteSpace(dto.Name))
                throw new ValidationException("Product name is required.");

            if (dto.Price <= 0)
                throw new ValidationException("Price must be greater than zero.");

            if (dto.Stock < 0)
                throw new ValidationException("Stock cannot be negative.");

            _logger.LogInformation("Creating product: {Name}", dto.Name);

            var product = new Product
            {
                Name = dto.Name.Trim(),
                Description = dto.Description?.Trim() ?? string.Empty,
                Price = dto.Price,
                ImageUrl = dto.ImageUrl?.Trim() ?? string.Empty,
                Stock = dto.Stock
            };

            var saved = await _productRepository.AddAsync(product);
            return MapToDTO(saved);
        }

        // ──────────────────────────────────────────────────────────────────────
        // UPDATE
        // ──────────────────────────────────────────────────────────────────────
        public async Task<ProductDTO> UpdateProductAsync(int id, UpdateProductDTO dto)
        {
            if (dto is null)
                throw new ValidationException("Update data cannot be null.");

            if (string.IsNullOrWhiteSpace(dto.Name))
                throw new ValidationException("Product name is required.");

            if (dto.Price <= 0)
                throw new ValidationException("Price must be greater than zero.");

            if (dto.Stock < 0)
                throw new ValidationException("Stock cannot be negative.");

            _logger.LogInformation("Updating product with ID {Id}", id);

            var existing = await _productRepository.GetByIdAsync(id)
                           ?? throw new NotFoundException($"Product with ID {id} was not found.");

            existing.Name = dto.Name.Trim();
            existing.Description = dto.Description?.Trim() ?? string.Empty;
            existing.Price = dto.Price;
            existing.ImageUrl = dto.ImageUrl?.Trim() ?? string.Empty;
            existing.Stock = dto.Stock;

            var updated = await _productRepository.UpdateAsync(existing);
            return MapToDTO(updated);
        }

        // ──────────────────────────────────────────────────────────────────────
        // DELETE
        // ──────────────────────────────────────────────────────────────────────
        public async Task DeleteProductAsync(int id)
        {
            if (id <= 0)
                throw new ValidationException("Invalid Product ID.");

            _logger.LogInformation("Deleting product with ID {Id}", id);

            var deleted = await _productRepository.DeleteAsync(id);

            if (!deleted)
                throw new NotFoundException($"Product with ID {id} was not found.");
        }

        // ──────────────────────────────────────────────────────────────────────
        // MAPPER
        // ──────────────────────────────────────────────────────────────────────
        private static ProductDTO MapToDTO(Product p) => new()
        {
            ProductId = p.ProductId,
            Name = p.Name,
            Description = p.Description,
            Price = p.Price,
            ImageUrl = p.ImageUrl,
            Stock = p.Stock
        };
    }
}
