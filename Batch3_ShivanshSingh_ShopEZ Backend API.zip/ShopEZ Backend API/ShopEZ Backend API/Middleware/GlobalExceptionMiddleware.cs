using ShopEZ_Backend_API.Exceptions;
using System.Net;
using System.Text.Json;
using ValidationException = ShopEZ_Backend_API.Exceptions.ValidationException;

namespace ShopEZ_Backend_API.Middleware
{
    /// <summary>
    /// Global exception-handling middleware.
    /// Catches all unhandled exceptions and returns a consistent JSON error response.
    /// </summary>
    public class GlobalExceptionMiddleware
    {
        private readonly RequestDelegate _next;
        private readonly ILogger<GlobalExceptionMiddleware> _logger;

        public GlobalExceptionMiddleware(RequestDelegate next, ILogger<GlobalExceptionMiddleware> logger)
        {
            _next = next;
            _logger = logger;
        }

        public async Task InvokeAsync(HttpContext context)
        {
            try
            {
                await _next(context);
            }
            catch (Exception ex)
            {
                await HandleExceptionAsync(context, ex);
            }
        }

        private async Task HandleExceptionAsync(HttpContext context, Exception ex)
        {
            HttpStatusCode statusCode;
            string message;

            switch (ex)
            {
                case NotFoundException nfe:
                    statusCode = HttpStatusCode.NotFound;
                    message = nfe.Message;
                    _logger.LogWarning("Not found: {Message}", nfe.Message);
                    break;

                case ValidationException ve:
                    statusCode = HttpStatusCode.BadRequest;
                    message = ve.Message;
                    _logger.LogWarning("Validation error: {Message}", ve.Message);
                    break;

                default:
                    statusCode = HttpStatusCode.InternalServerError;
                    message = "An unexpected error occurred. Please try again later.";
                    _logger.LogError(ex, "Unhandled exception: {Message}", ex.Message);
                    break;
            }

            context.Response.ContentType = "application/json";
            context.Response.StatusCode = (int)statusCode;

            var response = new
            {
                status = (int)statusCode,
                error = statusCode.ToString(),
                message
            };

            var json = JsonSerializer.Serialize(response, new JsonSerializerOptions
            {
                PropertyNamingPolicy = JsonNamingPolicy.CamelCase
            });

            await context.Response.WriteAsync(json);
        }
    }

    // Extension method for clean registration in Program.cs
    public static class GlobalExceptionMiddlewareExtensions
    {
        public static IApplicationBuilder UseGlobalExceptionHandler(this IApplicationBuilder app)
        {
            return app.UseMiddleware<GlobalExceptionMiddleware>();
        }
    }
}