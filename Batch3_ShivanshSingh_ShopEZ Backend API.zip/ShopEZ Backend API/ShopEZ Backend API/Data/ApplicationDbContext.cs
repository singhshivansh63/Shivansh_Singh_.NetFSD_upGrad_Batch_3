using Microsoft.EntityFrameworkCore;
using ShopEZ_Backend_API.Models;

namespace ShopEZ_Backend_API.Data
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
        }

        public DbSet<User> Users { get; set; }
        public DbSet<Product> Products { get; set; }
        public DbSet<Order> Orders { get; set; }
        public DbSet<OrderItem> OrderItems { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            // ─── User ───────────────────────────────────────────────────────────
            modelBuilder.Entity<User>(entity =>
            {
                entity.HasKey(u => u.UserId);
                entity.Property(u => u.Name).IsRequired().HasMaxLength(100);
                entity.Property(u => u.Email).IsRequired().HasMaxLength(150);
                entity.HasIndex(u => u.Email).IsUnique();
                entity.Property(u => u.Password).IsRequired().HasMaxLength(256);
                entity.Property(u => u.Role).HasMaxLength(50).HasDefaultValue("Customer");
            });

            // ─── Product ────────────────────────────────────────────────────────
            modelBuilder.Entity<Product>(entity =>
            {
                entity.HasKey(p => p.ProductId);
                entity.Property(p => p.Name).IsRequired().HasMaxLength(200);
                entity.Property(p => p.Description).HasMaxLength(1000);
                entity.Property(p => p.Price).IsRequired().HasColumnType("decimal(18,2)");
                entity.Property(p => p.ImageUrl).HasMaxLength(500);
                entity.Property(p => p.Stock).IsRequired();
            });

            // ─── Order ──────────────────────────────────────────────────────────
            modelBuilder.Entity<Order>(entity =>
            {
                entity.HasKey(o => o.OrderId);
                entity.Property(o => o.OrderDate).IsRequired();
                entity.Property(o => o.TotalAmount).IsRequired().HasColumnType("decimal(18,2)");

                // One User → Many Orders
                entity.HasOne(o => o.User)
                      .WithMany(u => u.Orders)
                      .HasForeignKey(o => o.UserId)
                      .OnDelete(DeleteBehavior.Restrict);
            });

            // ─── OrderItem ──────────────────────────────────────────────────────
            modelBuilder.Entity<OrderItem>(entity =>
            {
                entity.HasKey(oi => oi.OrderItemId);
                entity.Property(oi => oi.Quantity).IsRequired();
                entity.Property(oi => oi.Price).IsRequired().HasColumnType("decimal(18,2)");

                // One Order → Many OrderItems
                entity.HasOne(oi => oi.Order)
                      .WithMany(o => o.OrderItems)
                      .HasForeignKey(oi => oi.OrderId)
                      .OnDelete(DeleteBehavior.Cascade);

                // One Product → Many OrderItems
                entity.HasOne(oi => oi.Product)
                      .WithMany(p => p.OrderItems)
                      .HasForeignKey(oi => oi.ProductId)
                      .OnDelete(DeleteBehavior.Restrict);
            });

            // ─── Seed Data ──────────────────────────────────────────────────────
            modelBuilder.Entity<User>().HasData(
                new User { UserId = 1, Name = "Admin User",    Email = "admin@shopez.com",    Password = "Admin@123",    Role = "Admin"    },
                new User { UserId = 2, Name = "John Doe",      Email = "john@example.com",    Password = "John@123",     Role = "Customer" },
                new User { UserId = 3, Name = "Jane Smith",    Email = "jane@example.com",    Password = "Jane@123",     Role = "Customer" }
            );

            modelBuilder.Entity<Product>().HasData(
                new Product { ProductId = 1, Name = "Wireless Headphones",  Description = "Noise-cancelling over-ear headphones with 30h battery life.", Price = 2999.99m, ImageUrl = "https://via.placeholder.com/300x300?text=Headphones",  Stock = 50 },
                new Product { ProductId = 2, Name = "Mechanical Keyboard",  Description = "TKL mechanical keyboard with blue switches and RGB backlight.", Price = 3499.00m, ImageUrl = "https://via.placeholder.com/300x300?text=Keyboard",     Stock = 30 },
                new Product { ProductId = 3, Name = "USB-C Hub 7-in-1",     Description = "7-port USB-C hub: HDMI, USB-A x3, SD, TF, PD charging.",      Price = 1799.50m, ImageUrl = "https://via.placeholder.com/300x300?text=USBHub",       Stock = 100},
                new Product { ProductId = 4, Name = "Ergonomic Mouse",      Description = "Vertical ergonomic mouse with adjustable DPI up to 3200.",    Price = 1299.00m, ImageUrl = "https://via.placeholder.com/300x300?text=Mouse",        Stock = 75 },
                new Product { ProductId = 5, Name = "27-inch Monitor",      Description = "4K IPS monitor with 144Hz refresh rate and HDR support.",     Price = 24999.00m,ImageUrl = "https://via.placeholder.com/300x300?text=Monitor",      Stock = 20 }
            );
        }
    }
}
