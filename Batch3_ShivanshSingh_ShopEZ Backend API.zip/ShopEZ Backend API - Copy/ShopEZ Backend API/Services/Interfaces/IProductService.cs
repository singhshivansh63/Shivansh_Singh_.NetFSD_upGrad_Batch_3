using ShopEZ_Backend_API.DTOs;

namespace ShopEZ_Backend_API.Services.Interfaces
{
    public interface IProductService
    {
         
        Task<IEnumerable<ProductDTO>> GetAllProductsAsync(int page = 1, int pageSize = 5);

    
        Task<ProductDTO> GetProductByIdAsync(int id);

       
        Task<ProductDTO> CreateProductAsync(CreateProductDTO dto);

        
        Task<ProductDTO> UpdateProductAsync(int id, UpdateProductDTO dto);

     
        Task DeleteProductAsync(int id);
    }
}