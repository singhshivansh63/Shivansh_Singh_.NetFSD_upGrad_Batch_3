using ShopEZ_Backend_API.Data;
using ShopEZ_Backend_API.DTOs;
using ShopEZ_Backend_API.Exceptions;
using ShopEZ_Backend_API.Models;
using ShopEZ_Backend_API.Repositories.Interfaces;
using ShopEZ_Backend_API.Services.Interfaces;
using Microsoft.EntityFrameworkCore;

namespace ShopEZ_Backend_API.Services
{
    public class OrderService : IOrderService
    {
        private readonly IOrderRepository _orderRepository;
        private readonly IProductRepository _productRepository;
        private readonly ApplicationDbContext _context;
        private readonly ILogger<OrderService> _logger;

        public OrderService(
            IOrderRepository orderRepository,
            IProductRepository productRepository,
            ApplicationDbContext context,
            ILogger<OrderService> logger)
        {
            _orderRepository = orderRepository;
            _productRepository = productRepository;
            _context = context;
            _logger = logger;
        }

        //  CREATE ORDER
        public async Task<OrderDTO> CreateOrderAsync(CreateOrderDTO dto)
        {
            //  1. Validate DTO
            if (dto == null)
                throw new ValidationException("Order data cannot be null.");

            if (dto.UserId <= 0 || dto.UserId == int.MaxValue)
                throw new ValidationException("Invalid UserId provided.");

            if (dto.CartItems == null || !dto.CartItems.Any())
                throw new ValidationException("Cart must contain at least one item.");

            _logger.LogInformation("Incoming UserId: {UserId}", dto.UserId);

            //  2. Validate User
            var user = await _context.Users
                .FirstOrDefaultAsync(u => u.UserId == dto.UserId);

            if (user == null)
                throw new NotFoundException($"User with ID {dto.UserId} was not found.");

            //  3. Validate Products + Prepare Items
            var orderItems = new List<OrderItem>();

            foreach (var item in dto.CartItems)
            {
                if (item.Quantity <= 0)
                    throw new ValidationException($"Invalid quantity for ProductId {item.ProductId}");

                var product = await _productRepository.GetByIdAsync(item.ProductId)
                              ?? throw new NotFoundException($"Product {item.ProductId} not found");

                if (product.Stock < item.Quantity)
                    throw new ValidationException(
                        $"Insufficient stock for {product.Name}");

                orderItems.Add(new OrderItem
                {
                    ProductId = product.ProductId,
                    Quantity = item.Quantity,
                    Price = product.Price
                });
            }

            //  4. Calculate Total
            decimal total = orderItems.Sum(x => x.Price * x.Quantity);

            var order = new Order
            {
                UserId = dto.UserId,
                OrderDate = DateTime.UtcNow,
                TotalAmount = total,
                OrderItems = orderItems
            };

            //  5. TRANSACTION  
            //  5. EXECUTION STRATEGY (FIXED)
            var strategy = _context.Database.CreateExecutionStrategy();

            return await strategy.ExecuteAsync(async () =>
            {
                using var transaction = await _context.Database.BeginTransactionAsync();

                try
                {
                    await _orderRepository.AddAsync(order);

                    //  Update Stock
                    foreach (var item in dto.CartItems)
                    {
                        var product = await _context.Products.FindAsync(item.ProductId);
                        if (product != null)
                            product.Stock -= item.Quantity;
                    }

                    //  SINGLE SaveChanges
                    await _context.SaveChangesAsync();

                    await transaction.CommitAsync();

                    _logger.LogInformation("Order created successfully");

                    var fullOrder = await _orderRepository.GetByIdAsync(order.OrderId);

                    return MapToDTO(fullOrder);
                }
                catch (Exception ex)
                {
                    await transaction.RollbackAsync();
                    _logger.LogError(ex, "Error creating order");
                    throw;
                }
            });
        }
            

        //  GET ALL
        public async Task<IEnumerable<OrderSummaryDTO>> GetAllOrdersAsync()
        {
            var orders = await _orderRepository.GetAllAsync();

            return orders.Select(o => new OrderSummaryDTO
            {
                OrderId = o.OrderId,
                UserId = o.UserId,
                UserName = o.User?.Name ?? "Unknown",
                OrderDate = o.OrderDate,
                TotalAmount = o.TotalAmount,
                ItemCount = o.OrderItems.Sum(x => x.Quantity)
            });
        }

        //  GET BY ID
        public async Task<OrderDTO> GetOrderByIdAsync(int id)
        {
            var order = await _orderRepository.GetByIdAsync(id)
                        ?? throw new NotFoundException($"Order {id} not found");

            return MapToDTO(order);
        }

        //  MAPPER
        private static OrderDTO MapToDTO(Order o) => new()
        {
            OrderId = o.OrderId,
            UserId = o.UserId,
            UserName = o.User?.Name ?? "Unknown",
            OrderDate = o.OrderDate,
            TotalAmount = o.TotalAmount,
            OrderItems = o.OrderItems.Select(oi => new OrderItemDTO
            {
                OrderItemId = oi.OrderItemId,
                ProductId = oi.ProductId,
                ProductName = oi.Product?.Name ?? "Unknown",
                Quantity = oi.Quantity,
                Price = oi.Price
            }).ToList()
        };
    }
}