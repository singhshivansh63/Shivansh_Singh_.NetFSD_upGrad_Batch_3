using Microsoft.AspNetCore.Mvc;
using ShopEZ_Backend_API.DTOs;
using ShopEZ_Backend_API.Services.Interfaces;

namespace ShopEZ_Backend_API.Controllers
{
   
    [ApiController]
    [Route("api/orders")]
    [Produces("application/json")]
    public class OrdersController : ControllerBase
    {
        private readonly IOrderService _orderService;
        private readonly ILogger<OrdersController> _logger;

        public OrdersController(IOrderService orderService, ILogger<OrdersController> logger)
        {
            _orderService = orderService;
            _logger       = logger;
        }

        // ──────────────────────────────────────────────────────────────────────
        // POST /api/orders
        // ──────────────────────────────────────────────────────────────────────
       
        
        [HttpPost]
        [ProducesResponseType(typeof(OrderDTO), StatusCodes.Status201Created)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        public async Task<IActionResult> CreateOrder([FromBody] CreateOrderDTO dto)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            _logger.LogInformation("POST /api/orders called for UserId {UserId}.", dto.UserId);
            var created = await _orderService.CreateOrderAsync(dto);
            return CreatedAtAction(nameof(GetOrder), new { id = created.OrderId }, created);
        }

        // ──────────────────────────────────────────────────────────────────────
        // GET /api/orders
        // ──────────────────────────────────────────────────────────────────────
        
        
        [HttpGet]
        [ProducesResponseType(typeof(IEnumerable<OrderSummaryDTO>), StatusCodes.Status200OK)]
        public async Task<IActionResult> GetAllOrders()
        {
            _logger.LogInformation("GET /api/orders called.");
            var orders = await _orderService.GetAllOrdersAsync();
            return Ok(orders);
        }

        // ──────────────────────────────────────────────────────────────────────
        // GET /api/orders/{id}
        // ──────────────────────────────────────────────────────────────────────
       
        [HttpGet("{id:int}")]
        [ProducesResponseType(typeof(OrderDTO), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        public async Task<IActionResult> GetOrder(int id)
        {
            _logger.LogInformation("GET /api/orders/{Id} called.", id);
            var order = await _orderService.GetOrderByIdAsync(id);
            return Ok(order);
        }
    }
}
