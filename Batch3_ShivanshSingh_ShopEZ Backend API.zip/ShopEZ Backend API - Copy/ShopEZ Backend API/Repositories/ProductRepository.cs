using Microsoft.EntityFrameworkCore;
using ShopEZ_Backend_API.Data;
using ShopEZ_Backend_API.Models;
using ShopEZ_Backend_API.Repositories.Interfaces;

namespace ShopEZ_Backend_API.Repositories
{
    public class ProductRepository : IProductRepository
    {
        private readonly ApplicationDbContext _context;

        public ProductRepository(ApplicationDbContext context)
        {
            _context = context;
        }

       
        public async Task<IEnumerable<Product>> GetAllAsync()
        {
            return await _context.Products
                                 .AsNoTracking()
                                 .ToListAsync();
        }

        
        public async Task<Product?> GetByIdAsync(int id)
        {
            return await _context.Products
                                 .AsNoTracking()
                                 .FirstOrDefaultAsync(p => p.ProductId == id);
        }

        
        public async Task<Product> AddAsync(Product product)
        {
            await _context.Products.AddAsync(product);
            await _context.SaveChangesAsync();
            return product;
        }

        
        public async Task<Product> UpdateAsync(Product product)
        {
            _context.Products.Update(product);
            await _context.SaveChangesAsync();
            return product;
        }

       
        public async Task<bool> DeleteAsync(int id)
        {
            var product = await _context.Products.FindAsync(id);
            if (product is null) return false;

            _context.Products.Remove(product);
            await _context.SaveChangesAsync();
            return true;
        }

     
        public async Task<bool> ExistsAsync(int id)
        {
            return await _context.Products.AnyAsync(p => p.ProductId == id);
        }
    }
}
