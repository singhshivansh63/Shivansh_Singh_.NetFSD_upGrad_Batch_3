using Microsoft.EntityFrameworkCore;
using ShopEZ_Backend_API.Data;
using ShopEZ_Backend_API.Models;
using ShopEZ_Backend_API.Repositories.Interfaces;

namespace ShopEZ_Backend_API.Repositories
{
    public class OrderRepository : IOrderRepository
    {
        private readonly ApplicationDbContext _context;

        public OrderRepository(ApplicationDbContext context)
        {
            _context = context;
        }

       
        public async Task<IEnumerable<Order>> GetAllAsync()
        {
            return await _context.Orders
                                 .AsNoTracking()
                                 .Include(o => o.User)
                                 .Include(o => o.OrderItems)
                                     .ThenInclude(oi => oi.Product)
                                 .OrderByDescending(o => o.OrderDate)
                                 .ToListAsync();
        }

        
        public async Task<Order?> GetByIdAsync(int id)
        {
            return await _context.Orders
                                 .AsNoTracking()
                                 .Include(o => o.User)
                                 .Include(o => o.OrderItems)
                                     .ThenInclude(oi => oi.Product)
                                 .FirstOrDefaultAsync(o => o.OrderId == id);
        }

       
        public async Task<Order> AddAsync(Order order)
        {
            await _context.Orders.AddAsync(order);
            return order;  
        }
    }
}
